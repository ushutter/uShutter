#!/bin/bash

set -u

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
AVRDUDE="$SCRIPT_DIR/tools/avrdude"
AVRDUDE_CONF="$SCRIPT_DIR/tools/avrdude.conf"
FIRMWARE="$SCRIPT_DIR/firmware/uShutterUp-Nano-v2.0.0.hex"
EXPECTED_FIRMWARE_SHA256="5a9ec2b2b98140cc65402d5490376275daaf2b25c7d7c55c731525180f18d6d4"
PORT_OVERRIDE=""
DRY_RUN=0

pause_before_exit() {
  if [ -t 0 ]; then
    printf "\nPress Return to close this window..."
    IFS= read -r _
  fi
}

fail() {
  printf "\nInstallation failed: %s\n" "$1" >&2
  pause_before_exit
  exit 1
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --port)
      [ "$#" -ge 2 ] || fail "A serial port path is required after --port"
      PORT_OVERRIDE="$2"
      shift 2
      ;;
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    *)
      fail "Unknown option: $1"
      ;;
  esac
done

printf "========================================\n"
printf " uShutterUp Nano v2.0.0 Firmware Installer\n"
printf "========================================\n\n"

[ -x "$AVRDUDE" ] || fail "Upload tool tools/avrdude is missing"
[ -f "$AVRDUDE_CONF" ] || fail "Configuration file tools/avrdude.conf is missing"
[ -f "$FIRMWARE" ] || fail "Firmware file firmware/uShutterUp-Nano-v2.0.0.hex is missing"

ACTUAL_FIRMWARE_SHA256="$(/usr/bin/shasum -a 256 "$FIRMWARE" | /usr/bin/cut -d ' ' -f 1)"
[ "$ACTUAL_FIRMWARE_SHA256" = "$EXPECTED_FIRMWARE_SHA256" ] || \
  fail "Firmware verification failed. Please download the installer again."

if [ "$DRY_RUN" -eq 0 ]; then
  "$AVRDUDE" -? >/dev/null 2>&1 || fail "avrdude cannot run. On an Apple silicon Mac, install Rosetta 2 first or contact the supplier for a signed build."
fi

PORT=""
if [ -n "$PORT_OVERRIDE" ]; then
  PORT="$PORT_OVERRIDE"
elif [ "$DRY_RUN" -eq 1 ]; then
  PORT="/dev/cu.uShutterUp-test"
else
  shopt -s nullglob
  ports=(
    /dev/cu.usbserial*
    /dev/cu.wchusbserial*
    /dev/cu.SLAB_USBtoUART*
    /dev/cu.usbmodem*
  )
  shopt -u nullglob

  if [ "${#ports[@]}" -eq 0 ]; then
    fail "No Nano serial port was found. Connect the device, close the Arduino IDE Serial Monitor, and try again."
  elif [ "${#ports[@]}" -eq 1 ]; then
    PORT="${ports[0]}"
  else
    printf "Multiple serial ports were found. Select the Nano port:\n"
    PS3="Enter a number: "
    select selected_port in "${ports[@]}"; do
      if [ -n "${selected_port:-}" ]; then
        PORT="$selected_port"
        break
      fi
      printf "Invalid selection. Please try again.\n"
    done
  fi
fi

printf "Firmware: uShutterUp-Nano-v2.0.0.hex\n"
printf "Serial port: %s\n\n" "$PORT"

upload_at_baud() {
  local baud="$1"
  local attempts="$2"
  "$AVRDUDE" \
    -C "$AVRDUDE_CONF" \
    -N \
    -p atmega328p \
    -c arduino \
    -P "$PORT" \
    -b "$baud" \
    -x "attempts=$attempts" \
    -D \
    -U "flash:w:$FIRMWARE:i"
}

prompt_for_manual_reset() {
  printf "\nAutomatic reset did not start the Nano bootloader.\n"
  printf "Press Return, then immediately press and release the RESET button on the Nano.\n"
  IFS= read -r _
}

if [ "$DRY_RUN" -eq 1 ]; then
  printf "DRY RUN: Firmware and tools are intact. Automatic and manual-reset upload paths are ready.\n"
  exit 0
fi

printf "Trying the current Nano bootloader at 115200 baud...\n"
if upload_at_baud 115200 3; then
  printf "\nInstallation succeeded. The firmware was written and verified.\n"
  pause_before_exit
  exit 0
fi

printf "\nThe current bootloader upload failed. Trying the old Nano bootloader at 57600 baud...\n"
/bin/sleep 2
if upload_at_baud 57600 3; then
  printf "\nInstallation succeeded. The firmware was written and verified.\n"
  pause_before_exit
  exit 0
fi

prompt_for_manual_reset
if upload_at_baud 115200 20; then
  printf "\nInstallation succeeded. The firmware was written and verified.\n"
  pause_before_exit
  exit 0
fi

prompt_for_manual_reset
if upload_at_baud 57600 20; then
  printf "\nInstallation succeeded. The firmware was written and verified.\n"
  pause_before_exit
  exit 0
fi

fail "Automatic and manual-reset uploads both failed. Check the USB cable, serial driver, bootloader, and board model."

uShutterUp Nano v2.0.0 — macOS Offline Installer
=================================================

System requirements
-------------------
- An Intel Mac, or an Apple silicon Mac with Rosetta 2 installed
- Arduino Nano / ATmega328P
- A USB data cable

Installation
------------
1. Connect the Nano to your Mac over USB.
2. Close the Arduino IDE Serial Monitor and any other application using the serial port.
3. Double-click "Install uShutterUp.command".
4. If more than one serial port is found, enter the number for the Nano port.
5. Wait for "Installation succeeded. The firmware was written and verified."

The installer first tries the current Nano bootloader at 115200 baud. If that
fails, it automatically tries the old Nano bootloader at 57600 baud. If the
board's automatic reset does not work, the installer then guides you through a
manual RESET-button retry. Arduino IDE is not required.

macOS security notice
---------------------
This is a command-line offline installer, not an Apple-notarized application. If
macOS blocks it the first time, Control-click "Install uShutterUp.command" in
Finder and select Open.

If avrdude cannot run on an Apple silicon Mac, open Terminal and run:

  softwareupdate --install-rosetta

Troubleshooting
---------------
- No serial port found: check the USB data cable and USB-to-serial driver, then
  reconnect the Nano.
- Upload failed: close the Arduino IDE Serial Monitor and try again.
- Manual reset prompt: press Return first, then immediately press and release
  the RESET button while the installer is trying to connect.
- CH340-based clone boards: some macOS versions may require the manufacturer's
  CH340/CH341 driver.
- Both bootloader methods failed: confirm that the board is an ATmega328P Nano,
  not a Nano Every, Nano 33, or another model.

Package contents
----------------
- firmware/uShutterUp-Nano-v2.0.0.hex: firmware image
- tools/avrdude: upload and write-verification utility
- tools/avrdude.conf: device configuration
- licenses/: avrdude GPLv2 license and corresponding source
- SHA256SUMS.txt: checksums for key package files

Firmware SHA-256
----------------
5a9ec2b2b98140cc65402d5490376275daaf2b25c7d7c55c731525180f18d6d4
